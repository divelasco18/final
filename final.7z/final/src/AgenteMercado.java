import java.util.Arrays;

public class AgenteMercado {
private long id;
private String nombre;
private PlantaGeneracion[] plantageneracion;
private String ciudad;
private String presidente;
private Double dinerodisponible;
public void mostrarplantageneracion() {
	for(PlantaGeneracion aveztruz:plantageneracion) {
		System.out.println(aveztruz);
	}
	
}
public AgenteMercado(long id, String nombre, PlantaGeneracion[] plantageneracion, String ciudad, String presidente,
		Double dinerodisponible) {
	super();
	this.id = id;
	this.nombre = nombre;
	this.plantageneracion = plantageneracion;
	this.ciudad = ciudad;
	this.presidente = presidente;
	this.dinerodisponible = dinerodisponible;
	
	
}
public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getNombre() {
	return nombre;
}
public void setNombre(String nombre) {
	this.nombre = nombre;
}
public PlantaGeneracion[] getPlantageneracion() {
	return plantageneracion;
}
public void setPlantageneracion(PlantaGeneracion[] plantageneracion) {
	this.plantageneracion = plantageneracion;
}
public String getCiudad() {
	return ciudad;
}
public void setCiudad(String ciudad) {
	this.ciudad = ciudad;
}
public String getPresidente() {
	return presidente;
}
public void setPresidente(String presidente) {
	this.presidente = presidente;
}
public Double getDinerodisponible() {
	return dinerodisponible;
}
public void setDinerodisponible(Double dinerodisponible) {
	this.dinerodisponible = dinerodisponible;
	
	
}
@Override
public String toString() {
	return "AgenteMercado [id=" + id + ", nombre=" + nombre + ", plantageneracion=" + Arrays.toString(plantageneracion)
			+ ", ciudad=" + ciudad + ", presidente=" + presidente + ", dinerodisponible=" + dinerodisponible + "]";
}

}


